<?php

$version = include 'config/version.php';
echo $version;
