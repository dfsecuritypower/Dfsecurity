# Security Policy

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| > 4   | :white_check_mark: |
| 3   | :x:                |


## Reporting a Vulnerability

If you have any vulnerability please report at hi@coollabs.io
