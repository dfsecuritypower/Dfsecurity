<?php

namespace App\Livewire\Source\Gitlab;

use Livewire\Component;

class Change extends Component
{
    public function render()
    {
        return view('livewire.source.gitlab.change');
    }
}
