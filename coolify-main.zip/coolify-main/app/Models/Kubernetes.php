<?php

namespace App\Models;

class Kubernetes extends BaseModel {}
